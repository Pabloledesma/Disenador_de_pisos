</div><!-- #detalle -->
</div>
<div class="row">
    <div class="col-md-6">
        <button class="btn-primary" id="guardar">Guardar</button>
        <button class="btn-primary" id="borrar">Borrar</button>
    </div>
    <div class="col-md-6" id="result">                  
    </div>
</div>
</div>		

<script src="<?php echo site_url('wp-content/plugins/Disenador_de_pisos/js/disenador_de_pisos.js'); ?>">
</script>